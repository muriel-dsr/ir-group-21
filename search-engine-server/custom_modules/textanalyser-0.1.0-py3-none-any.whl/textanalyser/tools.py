import re


def split_words(text: str) -> list:
    """
    Take a string, split string into words and return words as a list.

    Words are calculated by splitting by space and then using regex to find words. Any 'words' that are solely
    punctuation are not counted. Any other string is counted as word regardless of the content.

    :param text: str
    :return: int
    """
    raw_words = text.split()
    words = list()
    pattern = re.compile("(\\w.*\\b)")
    for word in raw_words:
        longest_string = pattern.search(word)
        if longest_string is not None and longest_string.group(0) != '':
            words.append(longest_string.group(0))

    return words


def split_sentences(raw_text: str) -> list:
    """
    Take a string, split string into sentences and return sentences as a list.

    Sentences are defined by using the ., ?, or ! character followed by a space or new-line character.

    :param raw_text: str
    :return: list
    """
    sentences = list()
    start_index = 0
    splitters = ['.', '?', '!']
    # remove end characters and new line characters
    text = raw_text.strip()
    text = text.replace('\n', '')
    # separate sentences by splitters and return list
    for index, letter in enumerate(text):
        try:
            if letter in splitters and text[index + 1] == ' ':
                sentences.append(text[start_index:index + 1])
                start_index = index + 2
        except IndexError:
            sentences.append(text[start_index:])
    return sentences if len(sentences) > 0 else [text]


def count_words(text: str) -> int:
    """
    Take a string and return the number of words as an int.

    Uses the split_words function for splitting the text into words.

    :param text: str
    :return: int
    """
    return len(split_words(text))


def count_sentences(text: str) -> int:
    """
    Take a string and return the number of sentences it contains.

    Use the split_sentence function for splitting the text into sentences.

    :param text: str
    :return: int
    """
    return len(split_sentences(text))


def list_words(text: str) -> dict:
    """
    Take a string and return a dictionary of individual words and their count and repeated words and their count.

    Use the split_words function to create a list of words. Then convert the list into a dictionary.
    Return a dictionary with two pairs. The first pair has the key of 'all' and a value of a dictionary containing
    a word, word-count, key-value pair for all distinct words. The second pair has the key of 'all' and a value of
    a dictionary containing a word, word-count, key-value pair for all distinct words with a count greater than 1.

    :param text: str
    :return: dict
    """
    word_dict = dict()
    words = split_words(text)
    for word in words:
        word = word.lower()
        word_dict[word] = word_dict.get(word, 0) + 1

    repeated_words = {k: v for (k, v) in word_dict.items() if v > 1}
    return {'all': word_dict, 'repeated': repeated_words}


def censor(text: str) -> str:
    """
    Take a str, search for words / phrases that require censoring, return censored text.

    This function is in its development phase and is not yet available. Currently, it will just return the text as it
    is inputted.

    :param text: str
    :return: str
    """
    censor_list = []
    for word in censor_list:
        censored_word = word[0] + ''.ljust(len(word) - 2, '*') + word[-1]
        print(word, censored_word)
        text = text.replace(word, censored_word)
    return text


def redactor(text: str) -> str:
    """
    Take a str, search for personal information that requires redacting, return redacted text.

    Use regex patterns to search for patterns and then replace the pattern with a redacted version. Personal
    information consists of email addresses.

    :param text: str
    :return: str
    """
    # email_pattern = re.compile("\\w+@\\w+\\w.\\w+")
    email_pattern = re.compile("[a-zA-Z.]+@+[a-zA-Z.]+")
    emails = email_pattern.findall(text)
    for email in emails:
        redaction = email[0] + ''.ljust(len(email) - 2, '*') + email[-1]
        text = re.sub(email, redaction, text)
    return text

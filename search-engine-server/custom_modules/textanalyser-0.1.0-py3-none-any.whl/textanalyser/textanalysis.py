import os.path
from textanalyser.golden_retriever import get_txt


def extract(path: str, remote: bool = False):
    """Accepts a string for path. If not remote (i.e. local), then check if file exists on the local system.
    If file exists extract text using the method decided by the file extension. Otherwise, return None """
    if remote:
        return None
    # Check if file exists
    if path == '' or path is None:
        raise ValueError('path variable must exist for this process to work')
    if not os.path.exists(path):
        raise FileNotFoundError
    file_ext = path.split('.')[-1]
    if file_ext == 'txt':
        text = get_txt(path)
    else:
        raise Exception('Apologies, it appears that this file type is not yet supported by this library...')
    return text

import textanalyser.tools as tools


class Content:
    """
    The Content class takes a str of text and creates a set of useful components and statistics for that text.

    Attributes

    raw_text: Pass the text string as is.

    sentences: Use the split_sentence function to split the text string into sentences and create a list.

    sentence_count: The length of sentences as an int.

    words: Use the split_words function to split the text into words and create a list of words.

    word_count: The length of words as an int.

    word_list: Use the list_words function to split the text into a dictionary containing two key-value pairs, the first has a key of 'all' and the value is a dictionary containing individual words and their count. The second has a key of 'repeated' and the value is a dictionary of individual words and their count, but only words with a count greater than 1.

    words_unique: A dictionary containing individual words and their count

    words_repeated: A dictionary containing individual words and their count, only contains words with a count \
    greater than 1.

    sentence_word_average: The average number of words per sentence as a float.

    word_length_average: The average number of letters per word as a float.

    Methods

    description: Dynamically acquire all variables created in __init__ or added later and return them in a dict.

    """

    def __init__(self, text: str):
        """
        Initialising the Content class creates the basic components and statistics.

        raw_text: Pass the text string as is.

        sentences: Use the split_sentence function to split the text string into sentences and create a list.

        sentence_count: The length of sentences as an int.

        words: Use the split_words function to split the text into words and create a list of words.

        word_count: The length of words as an int.

        word_list: Use the list_words function to split the text into a dictionary containing two key-value pairs, the first has a key of 'all' and the value is a dictionary containing individual words and their count. The second has a key of 'repeated' and the value is a dictionary of individual words and their count, but only words with a count greater than 1.

        words_unique: A dictionary containing individual words and their count

        words_repeated: A dictionary containing individual words and their count, only contains words with a count greater than 1.

        sentence_word_average: The average number of words per sentence as a float.

        word_length_average: The average number of letters per word as a float.

        :param text: str
        """
        self.raw_text = text
        self.sentences = tools.split_sentences(text)
        self.sentence_count = len(self.sentences)
        self.words = tools.split_words(text)
        self.word_count = len(self.words)
        self.word_list = tools.list_words(text)
        self.words_unique = self.word_list['all']
        self.words_repeated = self.word_list['repeated']
        self.sentence_word_average = self.word_count / self.sentence_count
        self.word_length_average = self.calculate_word_length_average()

    def calculate_word_length_average(self) -> float:
        """Calculate the length of every word in words and then return the average word count."""
        lengths = (len(word) for word in self.words)
        return sum(lengths) / len(self.words)

    def description(self):
        """Dynamically acquire all variables created in __init__ or added later and return them in a dict"""
        details = dict()
        for attribute in dir(self):
            genus = type(self.__getattribute__(attribute)).__name__
            if attribute[0:2] == '__' or genus == 'method' or attribute == 'description':
                continue
            else:
                details[attribute] = self.__getattribute__(attribute)
        return details

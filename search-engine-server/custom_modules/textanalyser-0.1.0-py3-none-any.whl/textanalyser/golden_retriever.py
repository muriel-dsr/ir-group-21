def get_txt(target: str):
    """ Extracts text from a file with .txt extension. Return a string of text"""
    file = open(target, 'r')
    text = file.read()
    file.close()
    return text

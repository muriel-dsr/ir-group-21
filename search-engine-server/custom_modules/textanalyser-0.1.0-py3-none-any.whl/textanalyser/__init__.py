"""
The Text analysis library is designed to extract and analyse text.

Classes

Content: The Content class takes a str of text and creates a set of useful components and statistics for that text.

Methods

split_words: Take a string, split string into words and return words as a list.

split_sentences: Take a string, split string into sentences and return sentences as a list.

count_words:  Take a string and return the number of words as an int.

count_sentences: Take a string and return the number of sentences it contains.

list_words: Take a string and return a dictionary of individual words and their count and repeated words and their count.

redactor: Take a str, search for personal information that requires redacting, return redacted text.
"""

from textanalyser.textanalysis import extract
from textanalyser.tools import count_words
from textanalyser.tools import list_words
from textanalyser.classes import Content
